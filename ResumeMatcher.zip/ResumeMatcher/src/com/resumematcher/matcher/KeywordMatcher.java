package com.resumematcher.matcher;

import com.resumematcher.model.Job;
import com.resumematcher.model.Resume;
import com.resumematcher.util.SkillDictionary;

import java.util.Set;

/** Weighted coverage: how much of the job's required skill weight does the resume cover? */
public class KeywordMatcher extends AbstractMatcher {

    @Override
    public double score(Resume resume, Job job) {
        Set<String> have = resume.skillNames();
        int total = 0;
        int covered = 0;
        for (String skill : job.getRequiredSkills()) {
            int w = SkillDictionary.weightOf(skill);
            total += w;
            if (have.contains(skill)) {
                covered += w;
            }
        }
        return total == 0 ? 0.0 : (double) covered / total;
    }

    @Override
    public String name() {
        return "Keyword";
    }
}
