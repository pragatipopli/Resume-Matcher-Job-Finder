package com.resumematcher.repository;

import com.resumematcher.exception.DatabaseException;
import com.resumematcher.model.Job;
import com.resumematcher.ui.SampleData;

/** Factory: chooses JDBC when the SQLite driver is on the classpath, otherwise falls back to memory. */
public final class RepositoryFactory {

    private RepositoryFactory() { }

    public static JobRepository createJobRepository() {
        if (JdbcJobRepository.driverAvailable()) {
            try {
                JobRepository repo = new JdbcJobRepository(JdbcJobRepository.DEFAULT_URL);
                if (repo.count() == 0) {
                    for (Job job : SampleData.jobs()) {
                        repo.save(job);
                    }
                }
                return repo;
            } catch (DatabaseException e) {
                System.out.println("[warn] JDBC unavailable (" + e.getMessage() + "); using memory.");
            }
        }
        JobRepository memory = new InMemoryJobRepository();
        for (Job job : SampleData.jobs()) {
            memory.save(job);
        }
        return memory;
    }
}
