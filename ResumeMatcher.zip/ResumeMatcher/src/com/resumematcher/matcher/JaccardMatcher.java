package com.resumematcher.matcher;

import com.resumematcher.model.Job;
import com.resumematcher.model.Resume;

import java.util.HashSet;
import java.util.Set;

/** Jaccard similarity = |A intersect B| / |A union B| on skill sets. */
public class JaccardMatcher extends AbstractMatcher {

    @Override
    public double score(Resume resume, Job job) {
        Set<String> a = new HashSet<>(resume.skillNames());
        Set<String> b = new HashSet<>(job.getRequiredSkills());

        Set<String> union = new HashSet<>(a);
        union.addAll(b);
        Set<String> intersection = new HashSet<>(a);
        intersection.retainAll(b);

        return union.isEmpty() ? 0.0 : (double) intersection.size() / union.size();
    }

    @Override
    public String name() {
        return "Jaccard";
    }
}
