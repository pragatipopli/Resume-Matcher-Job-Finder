package com.resumematcher.repository;

import com.resumematcher.exception.DatabaseException;
import com.resumematcher.exception.JobNotFoundException;
import com.resumematcher.model.Job;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Job storage in a SQLite table via JDBC: driver, Connection, Statement, PreparedStatement, ResultSet. */
public class JdbcJobRepository implements JobRepository {
    public static final String DEFAULT_URL = "jdbc:sqlite:resumematcher.db";
    private final String url;

    public JdbcJobRepository(String url) {
        this.url = url;
        initSchema();
    }

    /** True when the SQLite driver jar is on the classpath. */
    public static boolean driverAvailable() {
        try {
            Class.forName("org.sqlite.JDBC");          // loads and registers the driver
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    private Connection connect() {
        try {
            return DriverManager.getConnection(url);
        } catch (SQLException e) {
            throw new DatabaseException("Cannot connect to " + url, e);
        }
    }

    private void initSchema() {
        try (Connection con = connect(); Statement st = con.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS jobs ("
                    + "id INTEGER PRIMARY KEY, title TEXT, company TEXT, location TEXT, "
                    + "description TEXT, skills TEXT, min_years INTEGER)");
        } catch (SQLException e) {
            throw new DatabaseException("Cannot create schema", e);
        }
    }

    private Job map(ResultSet rs) throws SQLException {
        List<String> skills = Arrays.asList(rs.getString("skills").split(","));
        return new Job(rs.getInt("id"), rs.getString("title"), rs.getString("company"),
                rs.getString("location"), rs.getString("description"), skills, rs.getInt("min_years"));
    }

    @Override
    public List<Job> findAll() {
        List<Job> jobs = new ArrayList<>();
        try (Connection con = connect();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM jobs ORDER BY id")) {
            while (rs.next()) {
                jobs.add(map(rs));
            }
        } catch (SQLException e) {
            throw new DatabaseException("findAll failed", e);
        }
        return jobs;
    }

    @Override
    public Job findById(int id) throws JobNotFoundException {
        try (Connection con = connect();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM jobs WHERE id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("findById failed", e);
        }
        throw new JobNotFoundException(id);
    }

    @Override
    public void save(Job job) {
        String sql = "INSERT OR REPLACE INTO jobs (id, title, company, location, description, skills, min_years) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, job.getId());
            ps.setString(2, job.getTitle());
            ps.setString(3, job.getCompany());
            ps.setString(4, job.getLocation());
            ps.setString(5, job.getDescription());
            ps.setString(6, String.join(",", job.getRequiredSkills()));
            ps.setInt(7, job.getMinYears());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseException("save failed for job " + job.getId(), e);
        }
    }

    @Override
    public int count() {
        try (Connection con = connect();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM jobs")) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) {
            throw new DatabaseException("count failed", e);
        }
    }

    @Override
    public String storageName() {
        return "SQLite database via JDBC";
    }
}
