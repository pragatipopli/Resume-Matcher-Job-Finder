package com.resumematcher.util;

import com.resumematcher.exception.InvalidResumeException;

public final class InputValidator {
    private static final int MIN_RESUME_LENGTH = 30;

    private InputValidator() { }

    public static void validateResumeText(String text) throws InvalidResumeException {
        if (text == null || text.isBlank()) {
            throw new InvalidResumeException("Resume text is empty.");
        }
        if (text.trim().length() < MIN_RESUME_LENGTH) {
            throw new InvalidResumeException("Resume is too short (minimum " + MIN_RESUME_LENGTH + " characters).");
        }
    }

    public static boolean isValidEmail(String email) {
        return email != null && email.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
    }

    /** Wrapper-class conversion: Integer.valueOf with a default when the text is not a number. */
    public static Integer parseInteger(String text, Integer defaultValue) {
        try {
            return Integer.valueOf(text.trim());
        } catch (NumberFormatException | NullPointerException e) {
            return defaultValue;
        }
    }
}
