package com.resumematcher.concurrency;

import com.resumematcher.model.MatchResult;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Shared data written by many consumer threads, so access is guarded by intrinsic locks. */
public class SharedResultStore {
    private final Map<String, List<MatchResult>> results = new HashMap<>();
    private final List<String> failures = new ArrayList<>();
    private final Object failureLock = new Object();     // separate lock for the failure list
    private int processed = 0;

    public synchronized void add(String candidate, List<MatchResult> matches) {   // lock = this
        results.put(candidate, matches);
        processed++;                                   // compound action: must be atomic
    }

    public void recordFailure(String message) {
        synchronized (failureLock) {                   // synchronized block on a private lock
            failures.add(message);
        }
    }

    public synchronized int getProcessed() {
        return processed;
    }

    public synchronized Map<String, List<MatchResult>> snapshot() {
        return new TreeMap<>(results);                 // copy, so callers cannot break our state
    }

    public List<String> getFailures() {
        synchronized (failureLock) {
            return new ArrayList<>(failures);
        }
    }
}
