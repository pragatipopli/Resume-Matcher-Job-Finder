package com.resumematcher.service;

import com.resumematcher.exception.InvalidResumeException;
import com.resumematcher.exception.ResumeParseException;
import com.resumematcher.model.Resume;
import com.resumematcher.parser.ResumeParser;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Parses, validates and keeps resumes (TreeMap keeps them sorted by id). */
public class ResumeService {
    private final ResumeParser parser;
    private final Map<Integer, Resume> byId = new TreeMap<>();

    public ResumeService(ResumeParser parser) {
        this.parser = parser;
    }

    public Resume addFromText(String text) throws InvalidResumeException, ResumeParseException {
        Resume resume = parser.parse(text);
        byId.put(resume.getId(), resume);
        return resume;
    }

    public Resume addFromFile(String path) throws InvalidResumeException, ResumeParseException {
        return addFromText(loadFile(path));
    }

    /** Reads a .txt resume. Demonstrates try / multi-catch / finally. */
    private String loadFile(String path) throws ResumeParseException {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(path));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
            return sb.toString();
        } catch (FileNotFoundException | SecurityException e) {      // multi-catch
            throw new ResumeParseException("Cannot open file: " + path, e);
        } catch (IOException e) {
            throw new ResumeParseException("Error while reading: " + path, e);
        } finally {
            if (reader != null) {                                       // always runs
                try {
                    reader.close();
                } catch (IOException ignored) {
                    // nothing more we can do
                }
            }
        }
    }

    public Resume find(int id) {
        return byId.get(id);
    }

    public Resume latest() {
        Resume last = null;
        for (Resume r : byId.values()) {
            last = r;
        }
        return last;
    }

    public List<Resume> all() {
        return new ArrayList<>(byId.values());
    }
}
