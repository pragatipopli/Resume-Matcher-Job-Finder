Put sqlite-jdbc-*.jar here to enable JDBC mode (download from https://github.com/xerial/sqlite-jdbc/releases). Without it the app runs in in-memory mode.
