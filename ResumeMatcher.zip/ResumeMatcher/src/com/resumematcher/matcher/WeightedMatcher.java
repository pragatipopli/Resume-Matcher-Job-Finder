package com.resumematcher.matcher;

import com.resumematcher.model.Job;
import com.resumematcher.model.Resume;

/** Composite: blends two other matchers, e.g. 70% keyword + 30% TF-IDF. */
public class WeightedMatcher extends AbstractMatcher {
    private final JobMatcher first;
    private final JobMatcher second;
    private final double firstWeight;

    public WeightedMatcher(JobMatcher first, JobMatcher second, double firstWeight) {
        this.first = first;
        this.second = second;
        this.firstWeight = firstWeight;
    }

    @Override
    public double score(Resume resume, Job job) {
        return firstWeight * first.score(resume, job) + (1 - firstWeight) * second.score(resume, job);
    }

    @Override
    public String name() {
        return "Weighted(" + first.name() + " " + Math.round(firstWeight * 100) + "% + "
                + second.name() + " " + Math.round((1 - firstWeight) * 100) + "%)";
    }
}
