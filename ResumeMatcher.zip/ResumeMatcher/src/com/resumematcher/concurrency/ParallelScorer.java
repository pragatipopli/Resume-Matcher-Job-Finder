package com.resumematcher.concurrency;

import com.resumematcher.matcher.JobMatcher;
import com.resumematcher.model.Job;
import com.resumematcher.model.MatchResult;
import com.resumematcher.model.Resume;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Scores one resume against many jobs on a fixed thread pool (Callable + Future). */
public class ParallelScorer {
    private final JobMatcher matcher;
    private final int threads;

    public ParallelScorer(JobMatcher matcher, int threads) {
        this.matcher = matcher;
        this.threads = threads;
    }

    public List<MatchResult> scoreAll(Resume resume, List<Job> jobs) throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        try {
            List<Future<MatchResult>> futures = new ArrayList<>();
            for (Job job : jobs) {
                Callable<MatchResult> task = () -> matcher.match(resume, job);
                futures.add(pool.submit(task));
            }
            List<MatchResult> results = new ArrayList<>();
            for (Future<MatchResult> f : futures) {
                try {
                    results.add(f.get());               // blocks until that task finishes
                } catch (ExecutionException e) {
                    System.out.println("  scoring failed: " + e.getCause());
                }
            }
            Collections.sort(results);
            return results;
        } finally {
            pool.shutdown();
        }
    }
}
