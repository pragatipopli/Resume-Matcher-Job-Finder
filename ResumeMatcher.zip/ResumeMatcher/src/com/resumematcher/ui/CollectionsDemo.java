package com.resumematcher.ui;

import com.resumematcher.model.Job;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/** One short, labelled example of each collection type, all using the project's own job data. */
public class CollectionsDemo {

    public void run(List<Job> jobs) {
        List<String> titles = new ArrayList<>();
        for (Job j : jobs) {
            titles.add(j.getTitle());
        }
        System.out.println("ArrayList (fast get by index)     : titles.get(0) = " + titles.get(0));

        LinkedList<String> recent = new LinkedList<>(titles.subList(0, 3));
        recent.addFirst("(newest search)");
        recent.removeLast();
        System.out.println("LinkedList (cheap add/remove ends): " + recent);

        Set<String> hash = new HashSet<>();
        Set<String> linked = new LinkedHashSet<>();
        Set<String> sorted = new TreeSet<>();
        for (Job j : jobs) {
            for (String s : j.getRequiredSkills()) {
                hash.add(s);
                linked.add(s);
                sorted.add(s);
            }
        }
        System.out.println("HashSet (unique, no order)        : " + hash.size() + " unique skills");
        System.out.println("LinkedHashSet (insertion order)   : first 5 = " + firstN(linked, 5));
        System.out.println("TreeSet (sorted)                  : first 5 = " + firstN(sorted, 5));

        Map<String, Integer> demand = new HashMap<>();
        for (Job j : jobs) {
            for (String s : j.getRequiredSkills()) {
                demand.merge(s, 1, Integer::sum);
            }
        }
        System.out.println("HashMap (skill -> jobs needing it): java=" + demand.get("java") + ", git=" + demand.get("git"));

        Map<String, List<String>> byLocation = new TreeMap<>();
        for (Job j : jobs) {
            byLocation.computeIfAbsent(j.getLocation(), k -> new ArrayList<>()).add(j.getCompany());
        }
        System.out.println("TreeMap (locations sorted A-Z)    : " + byLocation);

        Deque<String> history = new ArrayDeque<>();
        history.push("search: java");
        history.push("search: python");
        System.out.println("Deque as stack (undo last search) : pop -> " + history.pop() + ", peek -> " + history.peek());

        Queue<String> pending = new LinkedList<>();
        pending.offer("resume A");
        pending.offer("resume B");
        System.out.println("Queue (FIFO)                      : poll -> " + pending.poll() + ", next -> " + pending.peek());

        PriorityQueue<Job> entryLevelFirst = new PriorityQueue<>(
                Comparator.comparingInt(Job::getMinYears).thenComparing(Job::getTitle));
        entryLevelFirst.addAll(jobs);
        System.out.println("PriorityQueue (lowest min-years)  : " + entryLevelFirst.poll().getTitle());

        ListIterator<String> lit = titles.listIterator();
        while (lit.hasNext()) {
            String t = lit.next();
            if (t.startsWith("Junior")) {
                lit.set(t.toUpperCase());          // edit while iterating
            }
        }
        StringBuilder back = new StringBuilder();
        while (lit.hasPrevious() && back.length() < 40) {
            back.append(lit.previous()).append(" | ");
        }
        System.out.println("ListIterator (walk backwards)     : " + back);

        List<Job> byCompany = new ArrayList<>(jobs);
        byCompany.sort(Comparator.comparing(Job::getCompany));
        System.out.println("Comparator (sort by company)      : " + byCompany.get(0).getCompany() + " ... "
                + byCompany.get(byCompany.size() - 1).getCompany());

        List<String> locations = new ArrayList<>();
        for (Job j : jobs) {
            locations.add(j.getLocation());
        }
        System.out.println("Collections.frequency             : Remote appears " + Collections.frequency(locations, "Remote") + " times");
        System.out.println("Collections.max                   : " + Collections.max(titles));
        List<String> readOnly = Collections.unmodifiableList(titles);
        try {
            readOnly.add("x");
        } catch (UnsupportedOperationException e) {
            System.out.println("unmodifiableList                  : add() threw UnsupportedOperationException");
        }
    }

    private List<String> firstN(Set<String> set, int n) {
        List<String> out = new ArrayList<>();
        for (String s : set) {
            if (out.size() == n) {
                break;
            }
            out.add(s);
        }
        return out;
    }
}
