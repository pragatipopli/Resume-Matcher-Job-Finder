package com.resumematcher.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/** Known skills with weights (TreeMap = sorted) and aliases (HashMap = fast lookup). */
public final class SkillDictionary {
    private static final Map<String, Integer> WEIGHTS = new TreeMap<>();
    private static final Map<String, String> ALIASES = new HashMap<>();

    static {
        add(3, "java", "python", "javascript", "typescript", "c++", "sql", "spring boot", "hibernate",
                "react", "angular", "node.js", "machine learning", "tensorflow", "microservices");
        add(2, "jdbc", "mysql", "postgresql", "mongodb", "redis", "kafka", "docker", "kubernetes", "aws",
                "rest api", "junit", "maven", "linux", "pandas", "multithreading", "collections",
                "data structures", "algorithms", "oop");
        add(1, "html", "css", "git", "figma", "ci/cd", "agile");

        alias("reactjs", "react");
        alias("nodejs", "node.js");
        alias("node", "node.js");
        alias("js", "javascript");
        alias("postgres", "postgresql");
        alias("ml", "machine learning");
        alias("dsa", "data structures");
        alias("restful", "rest api");
        alias("rest apis", "rest api");
        alias("threads", "multithreading");
        alias("concurrency", "multithreading");
        alias("oops", "oop");
        alias("object oriented", "oop");
        alias("spring", "spring boot");
        alias("k8s", "kubernetes");
        alias("jenkins", "ci/cd");
    }

    private SkillDictionary() { }

    private static void add(int weight, String... names) {
        for (String n : names) {
            WEIGHTS.put(n, weight);
        }
    }

    private static void alias(String from, String to) {
        ALIASES.put(from, to);
    }

    public static Set<String> allSkills() {
        return Collections.unmodifiableSet(WEIGHTS.keySet());
    }

    public static Map<String, String> aliases() {
        return Collections.unmodifiableMap(ALIASES);
    }

    public static int weightOf(String skill) {
        return WEIGHTS.getOrDefault(skill, 1);
    }

    public static boolean isKnown(String skill) {
        return WEIGHTS.containsKey(skill);
    }
}
