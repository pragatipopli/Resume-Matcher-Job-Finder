@echo off
if exist out rmdir /s /q out
mkdir out
dir /s /b src\*.java > sources.txt
javac -d out -cp "lib/*" @sources.txt && echo Build OK
del sources.txt
