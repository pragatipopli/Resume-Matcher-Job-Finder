package com.resumematcher.parser;

import com.resumematcher.exception.InvalidResumeException;
import com.resumematcher.model.Candidate;
import com.resumematcher.model.Resume;
import com.resumematcher.model.Skill;
import com.resumematcher.util.InputValidator;
import com.resumematcher.util.SkillDictionary;
import com.resumematcher.util.TextUtils;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns plain resume text into a Resume object: name, email, experience and skills. */
public class TextResumeParser implements ResumeParser {
    private static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
    private static final Pattern YEARS = Pattern.compile("(\\d{1,2})\\+?\\s*(?:years|year|yrs)", Pattern.CASE_INSENSITIVE);

    @Override
    public Resume parse(String rawText) throws InvalidResumeException {
        InputValidator.validateResumeText(rawText);

        String name = extractName(rawText);
        String email = extractEmail(rawText);
        int years = extractYears(rawText);

        Set<Skill> skills = extractSkills(rawText);
        if (skills.isEmpty()) {
            throw new InvalidResumeException("No known skills found in the resume.");
        }
        return new Resume(new Candidate(name, email, years), rawText, skills);
    }

    /** Finds known skills (and their aliases) inside free text, matching whole words only. */
    private Set<Skill> extractSkills(String text) {
        String padded = " " + TextUtils.normalize(text) + " ";   // spaces on both sides = whole-word match
        Set<Skill> found = new LinkedHashSet<>();                // keeps insertion order, no duplicates

        for (String skill : SkillDictionary.allSkills()) {
            if (padded.contains(" " + skill + " ")) {
                found.add(new Skill(skill, SkillDictionary.weightOf(skill)));
            }
        }
        for (Map.Entry<String, String> alias : SkillDictionary.aliases().entrySet()) {
            if (padded.contains(" " + alias.getKey() + " ")) {
                String canonical = alias.getValue();
                found.add(new Skill(canonical, SkillDictionary.weightOf(canonical)));
            }
        }
        return found;
    }

    private String extractName(String text) {
        for (String line : text.split("\\r?\\n")) {
            String trimmed = line.trim();
            if (!trimmed.isEmpty()) {
                String[] parts = trimmed.split("\\s[-\\u2013|,]\\s|,");
                String name = parts[0].trim();
                return name.length() > 40 ? "Unknown" : name;
            }
        }
        return "Unknown";
    }

    private String extractEmail(String text) {
        Matcher m = EMAIL.matcher(text);
        return m.find() ? m.group() : "not-provided@example.com";
    }

    private int extractYears(String text) {
        Matcher m = YEARS.matcher(text);
        int best = 0;
        while (m.find()) {
            Integer value = Integer.valueOf(m.group(1));   // wrapper class
            best = Math.max(best, value);
        }
        return best;
    }
}
