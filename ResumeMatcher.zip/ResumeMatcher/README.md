# Resume Matcher & Job Finder (Core Java, terminal)

Pure Java 17+ console project. No frameworks and no external libraries (the SQLite JDBC jar is optional).
The matching algorithms (keyword coverage, Jaccard, TF-IDF + cosine similarity, weighted blend) are written by hand.

**40 Java types:** 34 concrete classes, 2 abstract classes, 3 interfaces, 1 enum
(plus 2 small nested classes inside `ThreadDemo`).

## Run
```
build.bat           (Mac/Linux: ./build.sh)
run.bat --demo      (Mac/Linux: ./run.sh --demo)    automatic tour of every feature
run.bat             (Mac/Linux: ./run.sh)           interactive menu
```
Run from the project root (the folder that contains `src`, `resumes`, `build.bat`).

Optional JDBC mode: put `sqlite-jdbc-*.jar` in `lib/` and rebuild. Jobs are then stored in `resumematcher.db`.
Without the jar the app falls back to in-memory storage automatically.

## Menu
```
 1 Paste a resume          8 Batch-process (producer/consumer)
 2 Load resume from file   9 Thread demos (states, race condition)
 3 Load sample resumes    10 Collections demo
 4 List resumes           11 Switch matching algorithm
 5 Top jobs for a resume  12 Export report to file
 6 Top jobs (parallel)    13 Search jobs by keyword
 7 Skill gap analysis      0 Exit
```

## Classes (40)
| Package | Types |
|---|---|
| `model` (7) | Person (abstract), Candidate, Resume, Job, Skill, MatchResult, ExperienceLevel (enum) |
| `exception` (4) | InvalidResumeException, ResumeParseException, JobNotFoundException (checked); DatabaseException (unchecked) |
| `util` (3) | TextUtils, SkillDictionary, InputValidator |
| `parser` (2) | ResumeParser (interface), TextResumeParser |
| `matcher` (7) | JobMatcher (interface), AbstractMatcher (abstract), KeywordMatcher, JaccardMatcher, TfIdfMatcher, WeightedMatcher, ScoreComparator |
| `repository` (4) | JobRepository (interface), InMemoryJobRepository, JdbcJobRepository, RepositoryFactory |
| `concurrency` (7) | ResumeQueue, ProducerTask, ConsumerTask, SharedResultStore, ParallelScorer, MonitorThread, ThreadDemo |
| `service` (2) | ResumeService, JobFinderService |
| `ui` (4) | Main, ConsoleMenu, CollectionsDemo, SampleData |

## Syllabus map (where to point in the viva)
| Topic | Where |
|---|---|
| Classes, objects, constructors, this/static | `Resume` (static `nextId`), `Job`, `Skill` (two constructors, `this(...)`) |
| Inheritance, polymorphism | `Person` -> `Candidate`; `AbstractMatcher` -> 4 matchers |
| Abstraction, interfaces | `JobMatcher`, `ResumeParser`, `JobRepository` (+ `default` method in `JobMatcher`) |
| Strings, StringBuilder | `TextUtils.normalize`, `ConsoleMenu.buildReport` |
| Wrapper classes | `InputValidator.parseInteger`, `TextResumeParser.extractYears` (`Integer.valueOf`) |
| Checked/unchecked, custom, try/catch/finally, multi-catch, throw/throws | `exception` package, `ResumeService.loadFile`, `ConsoleMenu` |
| ArrayList / LinkedList | `JobFinderService.rankAll`, `CollectionsDemo` |
| HashSet / LinkedHashSet / TreeSet | `TextUtils` (stop words), `TextResumeParser.extractSkills`, `Resume.skills` (TreeSet) |
| HashMap / LinkedHashMap / TreeMap | `TfIdfMatcher`, `SkillDictionary`, `InMemoryJobRepository`, `ResumeService` |
| Queue / Deque / PriorityQueue | `JobFinderService.topN` (bounded heap), `ResumeQueue` (Deque), `CollectionsDemo` |
| Iterator / ListIterator | `JobFinderService.filterByLocation`, `CollectionsDemo` |
| Comparable / Comparator, utility methods | `MatchResult`, `Skill`, `ScoreComparator`, `Collections.sort/max/frequency` |
| Threads, Runnable, sleep/join/interrupt | `ProducerTask`, `ConsumerTask`, `ThreadDemo` |
| Thread states, daemon, priority | `ThreadDemo.showStates`, `MonitorThread` |
| Race condition, synchronized method/block, intrinsic lock, atomicity, volatile | `ThreadDemo.showRaceCondition`, `SharedResultStore`, `Resume.allocateId`, `JobFinderService.matcher` |
| wait / notify / notifyAll, guarded block, producer-consumer | `ResumeQueue` + `ProducerTask` + `ConsumerTask` |
| Executor / Callable / Future | `ParallelScorer` |
| JDBC (driver, connection, Statement, PreparedStatement, ResultSet, try-with-resources) | `JdbcJobRepository` |

## How scoring works
- **Keyword**: share of the job's required-skill weight that the resume covers.
- **Jaccard**: shared skills divided by all distinct skills in both sets.
- **TF-IDF**: word vectors weighted by rarity, compared with cosine similarity.
- **Weighted** (default): 70% Keyword + 30% TF-IDF.

## Likely viva questions
1. **Why wait() inside a while loop, not an if?** A woken thread must re-check the condition (another thread may have acted first).
2. **Why notifyAll() and not notify()?** Producers and consumers wait on the same lock; notify() might wake the wrong kind of thread.
3. **Why is `count++` not thread-safe?** It is read, add, write. Two threads can read the same value. See `ThreadDemo.showRaceCondition`.
4. **Why a PriorityQueue for top-N?** A bounded heap keeps only N items, which is cheaper than sorting all results.
5. **Why does Skill override equals/hashCode?** So HashSet/TreeSet treat two skills with the same name as one.
6. **Why is DatabaseException unchecked?** Callers cannot meaningfully recover from a broken connection.
7. **Why an interface for matchers?** Strategy pattern: swap algorithms at runtime (menu option 11) without changing `JobFinderService`.
8. **Why a separate `failureLock`?** Failures and results are independent, so they need not block each other.
9. **What is the daemon thread for?** `MonitorThread` only reports progress; the JVM may exit without waiting for it.
10. **Why PreparedStatement?** It uses `?` placeholders, which prevents SQL injection and lets the database reuse the statement.

## Limits (be honest in the viva)
- Skill extraction is dictionary-based, so skills not in `SkillDictionary` are ignored.
- Input is plain text, not PDF.
- Jobs are seeded sample data, not scraped from live sites.
- Only jobs are stored in the database; resumes live in memory for the session.
- The matching is rule-based (information retrieval), not machine learning.
