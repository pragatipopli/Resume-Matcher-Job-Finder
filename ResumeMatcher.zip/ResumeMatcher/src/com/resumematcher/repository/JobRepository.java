package com.resumematcher.repository;

import com.resumematcher.exception.JobNotFoundException;
import com.resumematcher.model.Job;

import java.util.List;

public interface JobRepository {
    List<Job> findAll();

    Job findById(int id) throws JobNotFoundException;

    void save(Job job);

    int count();

    String storageName();
}
