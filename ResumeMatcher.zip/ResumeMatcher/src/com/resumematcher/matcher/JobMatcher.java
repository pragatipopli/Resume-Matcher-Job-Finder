package com.resumematcher.matcher;

import com.resumematcher.model.Job;
import com.resumematcher.model.MatchResult;
import com.resumematcher.model.Resume;

/** Strategy interface: every matching algorithm implements it. */
public interface JobMatcher {
    double score(Resume resume, Job job);

    MatchResult match(Resume resume, Job job);

    String name();

    default String describe() {
        return name() + " matcher";
    }
}
