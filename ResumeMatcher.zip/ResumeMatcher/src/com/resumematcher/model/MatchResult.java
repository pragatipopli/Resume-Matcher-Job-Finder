package com.resumematcher.model;

import java.util.List;

/** Result of matching one resume to one job. Natural order = best score first. */
public class MatchResult implements Comparable<MatchResult> {
    private final Job job;
    private final double score;          // 0.0 - 1.0
    private final List<String> matched;
    private final List<String> missing;
    private final String matcherName;

    public MatchResult(Job job, double score, List<String> matched, List<String> missing, String matcherName) {
        this.job = job;
        this.score = score;
        this.matched = matched;
        this.missing = missing;
        this.matcherName = matcherName;
    }

    public Job getJob() { return job; }
    public double getScore() { return score; }
    public List<String> getMatched() { return matched; }
    public List<String> getMissing() { return missing; }
    public String getMatcherName() { return matcherName; }

    public int getPercent() {
        return (int) Math.round(score * 100);
    }

    @Override
    public int compareTo(MatchResult other) {
        int byScore = Double.compare(other.score, this.score);   // descending
        return byScore != 0 ? byScore : job.getTitle().compareTo(other.job.getTitle());
    }

    @Override
    public String toString() {
        return String.format("%-28s %-12s %3d%%", job.getTitle(), job.getLocation(), getPercent());
    }
}
