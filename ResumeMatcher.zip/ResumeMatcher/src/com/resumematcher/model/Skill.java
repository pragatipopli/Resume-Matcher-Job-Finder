package com.resumematcher.model;

import java.util.Objects;

/** A skill with a weight. equals/hashCode use the name only so Sets de-duplicate; Comparable sorts by name. */
public class Skill implements Comparable<Skill> {
    private final String name;
    private final int weight;

    public Skill(String name, int weight) {
        this.name = name.toLowerCase();
        this.weight = weight;
    }

    public Skill(String name) {
        this(name, 1);
    }

    public String getName() {
        return name;
    }

    public int getWeight() {
        return weight;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Skill)) return false;
        return name.equals(((Skill) o).name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public int compareTo(Skill other) {
        return name.compareTo(other.name);
    }

    @Override
    public String toString() {
        return name;
    }
}
