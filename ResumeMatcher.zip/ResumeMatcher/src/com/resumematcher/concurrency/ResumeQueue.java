package com.resumematcher.concurrency;

import java.util.Deque;
import java.util.LinkedList;

/**
 * Bounded buffer built by hand with wait()/notifyAll() (guarded blocks).
 * The intrinsic lock is "this"; every method that touches the deque is synchronized.
 */
public class ResumeQueue {
    public static final String POISON_PILL = "__END_OF_RESUMES__";

    private final Deque<String> items = new LinkedList<>();
    private final int capacity;

    public ResumeQueue(int capacity) {
        this.capacity = capacity;
    }

    public synchronized void put(String text) throws InterruptedException {
        while (items.size() == capacity) {       // guarded block: re-check after every wake-up
            wait();                              // releases the lock and sleeps
        }
        items.addLast(text);
        notifyAll();                             // wake consumers waiting on an empty queue
    }

    public synchronized String take() throws InterruptedException {
        while (items.isEmpty()) {
            wait();
        }
        String text = items.removeFirst();
        notifyAll();                             // wake producers waiting on a full queue
        return text;
    }

    public synchronized int size() {
        return items.size();
    }
}
