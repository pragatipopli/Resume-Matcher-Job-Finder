package com.resumematcher.exception;

/** Checked exception: a resume could not be read or parsed (e.g. missing file). */
public class ResumeParseException extends Exception {
    public ResumeParseException(String message) {
        super(message);
    }

    public ResumeParseException(String message, Throwable cause) {
        super(message, cause);
    }
}
