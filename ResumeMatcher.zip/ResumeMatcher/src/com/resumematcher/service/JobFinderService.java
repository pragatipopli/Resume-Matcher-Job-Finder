package com.resumematcher.service;

import com.resumematcher.concurrency.ParallelScorer;
import com.resumematcher.matcher.JobMatcher;
import com.resumematcher.matcher.ScoreComparator;
import com.resumematcher.model.Job;
import com.resumematcher.model.MatchResult;
import com.resumematcher.model.Resume;
import com.resumematcher.repository.JobRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/** Core "job finder": ranks every job for a resume using the currently selected matcher. */
public class JobFinderService {
    private final JobRepository repository;
    private volatile JobMatcher matcher;       // volatile: a change made by one thread is seen by others

    public JobFinderService(JobRepository repository, JobMatcher matcher) {
        this.repository = repository;
        this.matcher = matcher;
    }

    public JobMatcher getMatcher() {
        return matcher;
    }

    public void setMatcher(JobMatcher matcher) {
        this.matcher = matcher;
    }

    public List<MatchResult> rankAll(Resume resume) {
        List<MatchResult> results = new ArrayList<>();
        for (Job job : repository.findAll()) {
            results.add(matcher.match(resume, job));
        }
        results.sort(new ScoreComparator());
        return results;
    }

    /**
     * Top-N using a PriorityQueue as a bounded heap. With reverseOrder() the head is the WORST kept
     * result, so when the heap grows past n we poll() to drop the worst.
     */
    public List<MatchResult> topN(Resume resume, int n) {
        PriorityQueue<MatchResult> heap = new PriorityQueue<>(Comparator.reverseOrder());
        for (Job job : repository.findAll()) {
            heap.offer(matcher.match(resume, job));
            if (heap.size() > n) {
                heap.poll();
            }
        }
        List<MatchResult> top = new ArrayList<>(heap);
        Collections.sort(top);                 // natural order of MatchResult = best first
        return top;
    }

    public List<MatchResult> rankParallel(Resume resume, int threads) throws InterruptedException {
        return new ParallelScorer(matcher, threads).scoreAll(resume, repository.findAll());
    }

    /** Removes non-matching locations in place using an Iterator (the safe way to delete while looping). */
    public List<MatchResult> filterByLocation(List<MatchResult> results, String location) {
        List<MatchResult> copy = new ArrayList<>(results);
        Iterator<MatchResult> it = copy.iterator();
        while (it.hasNext()) {
            if (!it.next().getJob().getLocation().equalsIgnoreCase(location)) {
                it.remove();
            }
        }
        return copy;
    }

    public List<MatchResult> filterByMinScore(List<MatchResult> results, int minPercent) {
        List<MatchResult> copy = new ArrayList<>();
        for (MatchResult r : results) {
            if (r.getPercent() >= minPercent) {
                copy.add(r);
            }
        }
        return copy;
    }

    public List<Job> searchByKeyword(String keyword) {
        String k = keyword.toLowerCase();
        List<Job> hits = new ArrayList<>();
        for (Job job : repository.findAll()) {
            if (job.getSearchText().toLowerCase().contains(k)) {
                hits.add(job);
            }
        }
        return hits;
    }

    /** Skills missing most often across the given results (HashMap counts, then sorted by count). */
    public Map<String, Integer> topMissingSkills(List<MatchResult> results, int limit) {
        Map<String, Integer> counts = new HashMap<>();
        for (MatchResult result : results) {
            for (String skill : result.getMissing()) {
                counts.merge(skill, 1, Integer::sum);
            }
        }
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(counts.entrySet());
        entries.sort((a, b) -> {
            int byCount = b.getValue().compareTo(a.getValue());
            return byCount != 0 ? byCount : a.getKey().compareTo(b.getKey());
        });
        Map<String, Integer> top = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> e : entries) {
            if (top.size() >= limit) {
                break;
            }
            top.put(e.getKey(), e.getValue());
        }
        return top;
    }
}
