#!/bin/sh
# Compile everything into ./out (add the SQLite JDBC jar to ./lib to enable the database mode)
rm -rf out && mkdir out
javac -d out -cp "lib/*" $(find src -name "*.java") && echo "Build OK"
