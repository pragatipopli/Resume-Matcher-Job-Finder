package com.resumematcher.repository;

import com.resumematcher.exception.JobNotFoundException;
import com.resumematcher.model.Job;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Fallback storage used when no JDBC driver is available. */
public class InMemoryJobRepository implements JobRepository {
    private final Map<Integer, Job> store = new LinkedHashMap<>();

    @Override
    public List<Job> findAll() {
        return new ArrayList<>(store.values());
    }

    @Override
    public Job findById(int id) throws JobNotFoundException {
        Job job = store.get(id);
        if (job == null) {
            throw new JobNotFoundException(id);
        }
        return job;
    }

    @Override
    public void save(Job job) {
        store.put(job.getId(), job);
    }

    @Override
    public int count() {
        return store.size();
    }

    @Override
    public String storageName() {
        return "in-memory (LinkedHashMap)";
    }
}
