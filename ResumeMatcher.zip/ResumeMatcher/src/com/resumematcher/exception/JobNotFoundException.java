package com.resumematcher.exception;

/** Checked exception: no job exists with the requested id. */
public class JobNotFoundException extends Exception {
    private final int jobId;

    public JobNotFoundException(int jobId) {
        super("No job found with id " + jobId);
        this.jobId = jobId;
    }

    public int getJobId() {
        return jobId;
    }
}
