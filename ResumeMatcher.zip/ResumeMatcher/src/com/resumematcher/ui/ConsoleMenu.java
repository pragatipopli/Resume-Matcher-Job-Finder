package com.resumematcher.ui;

import com.resumematcher.concurrency.ConsumerTask;
import com.resumematcher.concurrency.MonitorThread;
import com.resumematcher.concurrency.ProducerTask;
import com.resumematcher.concurrency.ResumeQueue;
import com.resumematcher.concurrency.SharedResultStore;
import com.resumematcher.concurrency.ThreadDemo;
import com.resumematcher.exception.InvalidResumeException;
import com.resumematcher.exception.JobNotFoundException;
import com.resumematcher.exception.ResumeParseException;
import com.resumematcher.matcher.JobMatcher;
import com.resumematcher.model.Job;
import com.resumematcher.model.MatchResult;
import com.resumematcher.model.Resume;
import com.resumematcher.parser.TextResumeParser;
import com.resumematcher.repository.JobRepository;
import com.resumematcher.service.JobFinderService;
import com.resumematcher.service.ResumeService;
import com.resumematcher.util.InputValidator;
import com.resumematcher.util.TextUtils;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ConsoleMenu {
    private final Scanner in = new Scanner(System.in);
    private final ResumeService resumes;
    private final JobFinderService finder;
    private final JobRepository jobs;
    private final Map<String, JobMatcher> matchers;

    public ConsoleMenu(ResumeService resumes, JobFinderService finder, JobRepository jobs,
                       Map<String, JobMatcher> matchers) {
        this.resumes = resumes;
        this.finder = finder;
        this.jobs = jobs;
        this.matchers = matchers;
    }

    // ------------------------------------------------------------ interactive loop
    public void run() {
        System.out.println("=== Resume Matcher & Job Finder ===");
        System.out.println("Storage: " + jobs.storageName() + " | Jobs loaded: " + jobs.count());
        boolean running = true;
        while (running) {
            printMenu();
            if (!in.hasNextLine()) {
                break;
            }
            Integer choice = InputValidator.parseInteger(in.nextLine(), -1);
            try {
                switch (choice) {
                    case 1: addPastedResume(); break;
                    case 2: addResumeFile(); break;
                    case 3: loadSamples(); break;
                    case 4: listResumes(); break;
                    case 5: showTopJobs(false); break;
                    case 6: showTopJobs(true); break;
                    case 7: showSkillGap(); break;
                    case 8: runBatch(SampleData.sampleResumes()); break;
                    case 9: threadDemos(); break;
                    case 10: new CollectionsDemo().run(jobs.findAll()); break;
                    case 11: switchMatcher(); break;
                    case 12: exportReport(); break;
                    case 13: searchJobs(); break;
                    case 0: running = false; break;
                    default: System.out.println("Please enter a number from the menu.");
                }
            } catch (InvalidResumeException | ResumeParseException e) {
                System.out.println("! " + e.getMessage());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                running = false;
            }
        }
        System.out.println("Goodbye.");
    }

    private void printMenu() {
        System.out.println();
        System.out.println(" 1  Paste a resume          8  Batch-process (producer/consumer)");
        System.out.println(" 2  Load resume from file   9  Thread demos (states, race condition)");
        System.out.println(" 3  Load sample resumes    10  Collections demo");
        System.out.println(" 4  List resumes           11  Switch matching algorithm");
        System.out.println(" 5  Top jobs for a resume  12  Export report to file");
        System.out.println(" 6  Top jobs (parallel)    13  Search jobs by keyword");
        System.out.println(" 7  Skill gap analysis      0  Exit");
        System.out.print("Choice [matcher: " + finder.getMatcher().name() + "]: ");
    }

    // ------------------------------------------------------------ actions
    private void addPastedResume() throws InvalidResumeException, ResumeParseException {
        System.out.println("Paste resume text, finish with a line containing only END:");
        StringBuilder sb = new StringBuilder();
        while (in.hasNextLine()) {
            String line = in.nextLine();
            if (line.trim().equals("END")) {
                break;
            }
            sb.append(line).append('\n');
        }
        Resume r = resumes.addFromText(sb.toString());
        System.out.println("Added: " + r);
    }

    private void addResumeFile() throws InvalidResumeException, ResumeParseException {
        System.out.print("File path (e.g. resumes/aarav.txt): ");
        Resume r = resumes.addFromFile(in.nextLine().trim());
        System.out.println("Added: " + r);
    }

    private void loadSamples() {
        int ok = 0;
        for (String text : SampleData.sampleResumes()) {
            try {
                Resume r = resumes.addFromText(text);
                System.out.println("  added " + r.getCandidate().getName());
                ok++;
            } catch (InvalidResumeException | ResumeParseException e) {
                System.out.println("  skipped invalid sample: " + e.getMessage());
            }
        }
        System.out.println(ok + " sample resumes loaded.");
    }

    private void listResumes() {
        List<Resume> all = resumes.all();
        if (all.isEmpty()) {
            System.out.println("No resumes yet. Use option 1, 2 or 3.");
        }
        for (Resume r : all) {
            System.out.println("  " + r);
        }
    }

    private Resume pickResume() {
        if (resumes.all().isEmpty()) {
            System.out.println("No resumes yet. Use option 1, 2 or 3 first.");
            return null;
        }
        listResumes();
        System.out.print("Resume id (Enter = latest): ");
        String text = in.nextLine();
        if (text.isBlank()) {
            return resumes.latest();
        }
        Resume r = resumes.find(InputValidator.parseInteger(text, -1));
        if (r == null) {
            System.out.println("No resume with that id.");
        }
        return r;
    }

    private void showTopJobs(boolean parallel) throws InterruptedException {
        Resume r = pickResume();
        if (r == null) {
            return;
        }
        List<MatchResult> ranked = parallel ? finder.rankParallel(r, 4) : finder.rankAll(r);
        System.out.println("\nBest jobs for " + r.getCandidate().getName() + " using " + finder.getMatcher().name()
                + (parallel ? " (4 threads)" : "") + ":");
        int rank = 1;
        for (MatchResult m : ranked.subList(0, Math.min(5, ranked.size()))) {
            System.out.printf("%2d. %s%n", rank++, m);
            System.out.println("      have: " + m.getMatched() + "   need: " + m.getMissing());
        }
    }

    private void showSkillGap() {
        Resume r = pickResume();
        if (r == null) {
            return;
        }
        List<MatchResult> top = finder.topN(r, 5);
        Map<String, Integer> missing = finder.topMissingSkills(top, 5);
        System.out.println("\nSkills to learn next (missing from " + top.size() + " best-matching jobs):");
        if (missing.isEmpty()) {
            System.out.println("  none, you cover every required skill.");
        }
        for (Map.Entry<String, Integer> e : missing.entrySet()) {
            System.out.println("  " + e.getKey() + "  (needed by " + e.getValue() + " jobs)");
        }
    }

    private void switchMatcher() {
        List<String> keys = new ArrayList<>(matchers.keySet());
        for (int i = 0; i < keys.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + keys.get(i) + "  -> " + matchers.get(keys.get(i)).describe());
        }
        System.out.print("Pick: ");
        Integer pick = InputValidator.parseInteger(in.nextLine(), 0);
        if (pick >= 1 && pick <= keys.size()) {
            finder.setMatcher(matchers.get(keys.get(pick - 1)));
            System.out.println("Now using: " + finder.getMatcher().name());
        } else {
            System.out.println("Unchanged.");
        }
    }

    private void exportReport() {
        Resume r = pickResume();
        if (r == null) {
            return;
        }
        String report = buildReport(r, finder.rankAll(r));
        String fileName = "report_" + r.getCandidate().getName().replaceAll("\\s+", "_") + ".txt";
        try (PrintWriter out = new PrintWriter(new FileWriter(fileName))) {      // try-with-resources
            out.print(report);
            System.out.println("Report written to " + fileName);
        } catch (IOException e) {
            System.out.println("! Could not write report: " + e.getMessage());
        }
    }

    private void searchJobs() {
        System.out.print("Keyword: ");
        List<Job> hits = finder.searchByKeyword(in.nextLine().trim());
        System.out.println(hits.size() + " job(s) found.");
        for (Job j : hits) {
            System.out.println("  " + j);
        }
        System.out.print("Open a job by id (Enter to skip): ");
        String text = in.nextLine();
        if (!text.isBlank()) {
            try {
                Job job = jobs.findById(InputValidator.parseInteger(text, -1));
                System.out.println("  " + job + "\n  " + job.getDescription() + "\n  Needs: " + job.getRequiredSkills());
            } catch (JobNotFoundException e) {
                System.out.println("! " + e.getMessage());
            }
        }
    }

    /** Builds a text report with StringBuilder (mutable string: no garbage from repeated +). */
    private String buildReport(Resume resume, List<MatchResult> results) {
        StringBuilder sb = new StringBuilder();
        String line = TextUtils.repeat("=", 64);
        sb.append("RESUME MATCH REPORT\n").append(line).append('\n');
        sb.append("Candidate : ").append(resume.getCandidate().getName()).append('\n');
        sb.append("Email     : ").append(resume.getCandidate().getEmail()).append('\n');
        sb.append("Level     : ").append(resume.getCandidate().getLevel()).append('\n');
        sb.append("Skills    : ").append(String.join(", ", resume.skillNames())).append('\n');
        sb.append(line).append('\n');
        int rank = 1;
        for (MatchResult m : results) {
            sb.append(String.format("%2d. %s%n", rank++, m));
            sb.append("     have: ").append(m.getMatched().isEmpty() ? "-" : String.join(", ", m.getMatched())).append('\n');
            sb.append("     need: ").append(m.getMissing().isEmpty() ? "-" : String.join(", ", m.getMissing())).append('\n');
        }
        sb.append(line).append('\n');
        sb.append("Matcher   : ").append(results.isEmpty() ? "n/a" : results.get(0).getMatcherName()).append('\n');
        return sb.toString();
    }

    // ------------------------------------------------------------ concurrency
    private void runBatch(List<String> texts) throws InterruptedException {
        System.out.println("\nBatch pipeline: 1 producer thread -> bounded queue -> 2 consumer threads");
        final int consumers = 2;
        ResumeQueue queue = new ResumeQueue(2);
        SharedResultStore store = new SharedResultStore();
        TextResumeParser parser = new TextResumeParser();

        Thread producer = new Thread(new ProducerTask(queue, texts, consumers), "producer");
        List<Thread> workers = new ArrayList<>();
        for (int i = 1; i <= consumers; i++) {
            workers.add(new Thread(new ConsumerTask(queue, parser, finder, store), "consumer-" + i));
        }
        MonitorThread monitor = new MonitorThread(store, texts.size());

        monitor.start();
        producer.start();
        for (Thread w : workers) {
            w.start();
        }
        producer.join();
        for (Thread w : workers) {
            w.join();
        }
        monitor.interrupt();

        System.out.println("\nResults (" + store.getProcessed() + " processed, " + store.getFailures().size() + " rejected):");
        for (Map.Entry<String, List<MatchResult>> e : store.snapshot().entrySet()) {
            System.out.println("  " + e.getKey() + " -> best: " + e.getValue().get(0));
        }
        for (String failure : store.getFailures()) {
            System.out.println("  rejected: " + failure);
        }
    }

    private void threadDemos() throws InterruptedException {
        System.out.println("\n-- Thread lifecycle --");
        ThreadDemo.showStates();
        System.out.println("\n-- Race condition vs synchronization --");
        ThreadDemo.showRaceCondition();
    }

    // ------------------------------------------------------------ non-interactive tour (java ... --demo)
    public void runDemo() throws InterruptedException {
        System.out.println("=== DEMO MODE ===");
        System.out.println("Storage: " + jobs.storageName() + " | Jobs: " + jobs.count());
        System.out.println("\n1) Loading sample resumes (last one is invalid on purpose)");
        loadSamples();

        Resume first = resumes.all().get(0);
        System.out.println("\n2) Top 3 jobs per algorithm for " + first.getCandidate().getName());
        for (String name : matchers.keySet()) {
            finder.setMatcher(matchers.get(name));
            List<MatchResult> top = finder.topN(first, 3);
            System.out.println("  [" + finder.getMatcher().name() + "]");
            for (MatchResult m : top) {
                System.out.println("     " + m);
            }
        }

        finder.setMatcher(matchers.get("weighted"));
        System.out.println("\n3) Parallel scoring with a thread pool");
        List<MatchResult> parallel = finder.rankParallel(first, 4);
        System.out.println("  best: " + parallel.get(0));

        System.out.println("\n4) Skill gap");
        System.out.println("  " + finder.topMissingSkills(finder.topN(first, 5), 5));

        System.out.println("\n5) Filter: Chandigarh jobs only");
        for (MatchResult m : finder.filterByLocation(finder.rankAll(first), "Chandigarh")) {
            System.out.println("     " + m);
        }

        System.out.println("\n6) Report preview");
        System.out.println(buildReport(first, finder.topN(first, 2)));

        System.out.println("7) Producer/consumer batch");
        runBatch(SampleData.sampleResumes());

        System.out.println("\n8) Thread demos");
        threadDemos();

        System.out.println("\n9) Collections demo");
        new CollectionsDemo().run(jobs.findAll());

        System.out.println("\n10) Exception handling demo");
        try {
            resumes.addFromFile("resumes/does_not_exist.txt");
        } catch (InvalidResumeException | ResumeParseException e) {
            System.out.println("  caught: " + e.getMessage());
        }
        try {
            jobs.findById(999);
        } catch (JobNotFoundException e) {
            System.out.println("  caught: " + e.getMessage() + " (id=" + e.getJobId() + ")");
        }
    }
}
