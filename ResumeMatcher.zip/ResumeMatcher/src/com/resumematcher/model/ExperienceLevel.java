package com.resumematcher.model;

/** Enum with fields and a static factory method. */
public enum ExperienceLevel {
    FRESHER(0), JUNIOR(1), MID(3), SENIOR(6);

    private final int minYears;

    ExperienceLevel(int minYears) {
        this.minYears = minYears;
    }

    public int getMinYears() {
        return minYears;
    }

    public static ExperienceLevel fromYears(int years) {
        ExperienceLevel result = FRESHER;
        for (ExperienceLevel level : values()) {
            if (years >= level.minYears) {
                result = level;
            }
        }
        return result;
    }
}
