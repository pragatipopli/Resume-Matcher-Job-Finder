package com.resumematcher.ui;

import com.resumematcher.matcher.JaccardMatcher;
import com.resumematcher.matcher.JobMatcher;
import com.resumematcher.matcher.KeywordMatcher;
import com.resumematcher.matcher.TfIdfMatcher;
import com.resumematcher.matcher.WeightedMatcher;
import com.resumematcher.parser.TextResumeParser;
import com.resumematcher.repository.JobRepository;
import com.resumematcher.repository.RepositoryFactory;
import com.resumematcher.service.JobFinderService;
import com.resumematcher.service.ResumeService;

import java.util.LinkedHashMap;
import java.util.Map;

/** Entry point: wires every layer together. Run with --demo for an automatic tour, or with no argument for the menu. */
public class Main {

    public static void main(String[] args) throws InterruptedException {
        JobRepository jobs = RepositoryFactory.createJobRepository();

        JobMatcher keyword = new KeywordMatcher();
        JobMatcher tfidf = new TfIdfMatcher(jobs.findAll());

        Map<String, JobMatcher> matchers = new LinkedHashMap<>();
        matchers.put("keyword", keyword);
        matchers.put("jaccard", new JaccardMatcher());
        matchers.put("tfidf", tfidf);
        matchers.put("weighted", new WeightedMatcher(keyword, tfidf, 0.7));

        ResumeService resumeService = new ResumeService(new TextResumeParser());
        JobFinderService finder = new JobFinderService(jobs, matchers.get("weighted"));
        ConsoleMenu menu = new ConsoleMenu(resumeService, finder, jobs, matchers);

        if (args.length > 0 && args[0].equals("--demo")) {
            menu.runDemo();
        } else {
            menu.run();
        }
    }
}
