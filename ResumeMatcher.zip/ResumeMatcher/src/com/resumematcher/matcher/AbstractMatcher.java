package com.resumematcher.matcher;

import com.resumematcher.model.Job;
import com.resumematcher.model.MatchResult;
import com.resumematcher.model.Resume;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Template-method pattern: match() is fixed, subclasses only supply score(). */
public abstract class AbstractMatcher implements JobMatcher {

    @Override
    public final MatchResult match(Resume resume, Job job) {
        List<String> matched = new ArrayList<>();
        List<String> missing = new ArrayList<>();
        Set<String> have = resume.skillNames();
        for (String required : job.getRequiredSkills()) {
            if (have.contains(required)) {
                matched.add(required);
            } else {
                missing.add(required);
            }
        }
        return new MatchResult(job, clamp(score(resume, job)), matched, missing, name());
    }

    protected double clamp(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }
}
