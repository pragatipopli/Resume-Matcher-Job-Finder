#!/bin/sh
# ./run.sh          interactive menu
# ./run.sh --demo   automatic tour of every feature
java -cp "out:lib/*" com.resumematcher.ui.Main "$@"
