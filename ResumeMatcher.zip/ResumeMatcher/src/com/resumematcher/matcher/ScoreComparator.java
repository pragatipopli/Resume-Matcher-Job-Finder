package com.resumematcher.matcher;

import com.resumematcher.model.MatchResult;

import java.util.Comparator;

/** Comparator (external ordering): highest score first, ties broken by job title. */
public class ScoreComparator implements Comparator<MatchResult> {

    @Override
    public int compare(MatchResult a, MatchResult b) {
        int byScore = Double.compare(b.getScore(), a.getScore());
        if (byScore != 0) {
            return byScore;
        }
        return a.getJob().getTitle().compareTo(b.getJob().getTitle());
    }
}
