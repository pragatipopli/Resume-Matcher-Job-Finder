package com.resumematcher.concurrency;

import com.resumematcher.exception.InvalidResumeException;
import com.resumematcher.exception.ResumeParseException;
import com.resumematcher.model.MatchResult;
import com.resumematcher.model.Resume;
import com.resumematcher.parser.ResumeParser;
import com.resumematcher.service.JobFinderService;

import java.util.List;

/** Takes raw resumes from the queue, parses and ranks them, stores the result. */
public class ConsumerTask implements Runnable {
    private final ResumeQueue queue;
    private final ResumeParser parser;
    private final JobFinderService finder;
    private final SharedResultStore store;

    public ConsumerTask(ResumeQueue queue, ResumeParser parser, JobFinderService finder, SharedResultStore store) {
        this.queue = queue;
        this.parser = parser;
        this.finder = finder;
        this.store = store;
    }

    @Override
    public void run() {
        String name = Thread.currentThread().getName();
        try {
            while (true) {
                String text = queue.take();
                if (ResumeQueue.POISON_PILL.equals(text)) {
                    System.out.println("  [" + name + "] got stop signal");
                    break;
                }
                try {
                    Resume resume = parser.parse(text);
                    List<MatchResult> top = finder.topN(resume, 3);
                    store.add(resume.getCandidate().getName(), top);
                    System.out.println("  [" + name + "] processed " + resume.getCandidate().getName());
                } catch (InvalidResumeException | ResumeParseException e) {
                    store.recordFailure(e.getMessage());
                    System.out.println("  [" + name + "] rejected a resume: " + e.getMessage());
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
