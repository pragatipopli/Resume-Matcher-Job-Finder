package com.resumematcher.concurrency;

import java.util.concurrent.atomic.AtomicInteger;

/** Two classroom demos: the six thread states, and a race condition with its two fixes. */
public class ThreadDemo {
    private static volatile boolean stopBusy;     // volatile: the busy thread must see main's change

    /** Walks a thread through NEW, RUNNABLE, BLOCKED, WAITING, TIMED_WAITING and TERMINATED. */
    public static void showStates() throws InterruptedException {
        stopBusy = false;

        Thread busy = new Thread(() -> {
            long spins = 0;
            while (!stopBusy) {
                spins++;
            }
        }, "busy");
        System.out.println("  NEW           : " + busy.getState());
        busy.setPriority(Thread.MIN_PRIORITY);
        busy.start();
        System.out.println("  RUNNABLE      : " + busy.getState() + " (priority " + busy.getPriority() + ")");
        stopBusy = true;
        busy.join();

        final Object lock = new Object();
        Thread blocked = new Thread(() -> {
            synchronized (lock) {
                // reached only after main releases the lock
            }
        }, "blocked");
        synchronized (lock) {
            blocked.start();
            Thread.sleep(150);
            System.out.println("  BLOCKED       : " + blocked.getState() + " (waiting for main's lock)");
        }
        blocked.join();

        final Object monitor = new Object();
        Thread waiter = new Thread(() -> {
            synchronized (monitor) {
                try {
                    monitor.wait();
                } catch (InterruptedException ignored) {
                    // not used here
                }
            }
        }, "waiter");
        waiter.start();
        Thread.sleep(150);
        System.out.println("  WAITING       : " + waiter.getState() + " (inside wait())");
        synchronized (monitor) {
            monitor.notify();
        }
        waiter.join();

        Thread sleeper = new Thread(() -> {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                System.out.println("    (sleeper was interrupted, so it stops early)");
            }
        }, "sleeper");
        sleeper.start();
        Thread.sleep(100);
        System.out.println("  TIMED_WAITING : " + sleeper.getState() + " (inside sleep(3000))");
        sleeper.interrupt();
        sleeper.join();

        System.out.println("  TERMINATED    : " + sleeper.getState());

        Thread daemon = new Thread(() -> { }, "daemon-demo");
        daemon.setDaemon(true);
        System.out.println("  Daemon thread : isDaemon=" + daemon.isDaemon());
    }

    static class UnsafeCounter {
        private int count;

        void increment() {
            int temp = count;      // 1. read
            Thread.yield();        // another thread may run here and also read the same value
            count = temp + 1;      // 2. write back: the other thread's update is lost
        }

        int get() {
            return count;
        }
    }

    static class SafeCounter {
        private int count;

        synchronized void increment() {
            count++;
        }

        synchronized int get() {
            return count;
        }
    }

    /** Four threads add to three counters: unsafe, synchronized and atomic. */
    public static void showRaceCondition() throws InterruptedException {
        final int threads = 4;
        final int perThread = 5_000;
        final UnsafeCounter unsafe = new UnsafeCounter();
        final SafeCounter safe = new SafeCounter();
        final AtomicInteger atomic = new AtomicInteger();

        Thread[] workers = new Thread[threads];
        for (int i = 0; i < threads; i++) {
            workers[i] = new Thread(() -> {
                for (int k = 0; k < perThread; k++) {
                    unsafe.increment();
                    safe.increment();
                    atomic.incrementAndGet();
                }
            }, "worker-" + i);
            workers[i].start();
        }
        for (Thread t : workers) {
            t.join();              // wait for all workers
        }
        System.out.println("  Expected total      : " + (threads * perThread));
        System.out.println("  Unsynchronized      : " + unsafe.get() + "   <- usually LESS (lost updates)");
        System.out.println("  synchronized method : " + safe.get());
        System.out.println("  AtomicInteger       : " + atomic.get());
    }
}
