package com.resumematcher.exception;

/** Checked exception: the resume text fails validation (empty, too short, no skills). */
public class InvalidResumeException extends Exception {
    public InvalidResumeException(String message) {
        super(message);
    }
}
