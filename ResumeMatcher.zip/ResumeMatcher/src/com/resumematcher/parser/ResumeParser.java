package com.resumematcher.parser;

import com.resumematcher.exception.InvalidResumeException;
import com.resumematcher.exception.ResumeParseException;
import com.resumematcher.model.Resume;

/** Interface: any parser (text, file, ...) can be plugged in. */
public interface ResumeParser {
    Resume parse(String rawText) throws InvalidResumeException, ResumeParseException;
}
