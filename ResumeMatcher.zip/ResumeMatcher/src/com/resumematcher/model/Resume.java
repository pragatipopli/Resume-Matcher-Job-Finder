package com.resumematcher.model;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Resume {
    private static int nextId = 1;          // static member shared by all objects

    private final int id;
    private final Candidate candidate;
    private final String rawText;
    private final Set<Skill> skills;

    public Resume(Candidate candidate, String rawText, Collection<Skill> skills) {
        this.id = allocateId();
        this.candidate = candidate;
        this.rawText = rawText;
        this.skills = new TreeSet<>(skills);   // sorted by Skill.compareTo
    }

    // synchronized static method: the lock is the Class object, so ids stay unique across threads
    private static synchronized int allocateId() {
        return nextId++;
    }

    public int getId() {
        return id;
    }

    public Candidate getCandidate() {
        return candidate;
    }

    public String getRawText() {
        return rawText;
    }

    public Set<Skill> getSkills() {
        return skills;
    }

    public Set<String> skillNames() {
        Set<String> names = new LinkedHashSet<>();
        for (Skill s : skills) {
            names.add(s.getName());
        }
        return names;
    }

    @Override
    public String toString() {
        return "#" + id + " " + candidate.getName() + " (" + candidate.getLevel() + ", "
                + candidate.getYearsOfExperience() + " yrs) skills=" + skills;
    }
}
