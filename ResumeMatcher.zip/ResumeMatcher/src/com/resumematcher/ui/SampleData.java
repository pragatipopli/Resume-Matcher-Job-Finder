package com.resumematcher.ui;

import com.resumematcher.model.Job;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Seed data: 12 jobs and a few sample resumes (one deliberately invalid). */
public final class SampleData {
    private SampleData() { }

    public static List<Job> jobs() {
        List<Job> jobs = new ArrayList<>();
        jobs.add(new Job(1, "Java Backend Developer", "Finlytics", "Bengaluru",
                "Build secure payment APIs with Spring Boot and relational databases. Write unit tests.",
                Arrays.asList("java", "spring boot", "sql", "rest api", "junit", "git"), 1));
        jobs.add(new Job(2, "Junior Java Developer", "CampusCart", "Chandigarh",
                "Work on an e-commerce platform using core Java, collections and JDBC with MySQL.",
                Arrays.asList("java", "oop", "collections", "jdbc", "mysql", "git"), 0));
        jobs.add(new Job(3, "Full Stack Engineer", "Notebook Labs", "Remote",
                "Ship features across a React front end and Node.js services backed by MongoDB.",
                Arrays.asList("javascript", "react", "node.js", "mongodb", "html", "css", "git"), 2));
        jobs.add(new Job(4, "Data Analyst", "Orbit Retail", "Gurugram",
                "Analyse sales data with Python and pandas, build dashboards and simple predictive models.",
                Arrays.asList("python", "sql", "pandas", "machine learning", "git"), 1));
        jobs.add(new Job(5, "Machine Learning Engineer", "Vistara AI", "Bengaluru",
                "Train and deploy models for document understanding on cloud infrastructure.",
                Arrays.asList("python", "machine learning", "tensorflow", "docker", "aws", "algorithms"), 2));
        jobs.add(new Job(6, "Microservices Developer", "Cartwheel", "Pune",
                "Design event-driven microservices with Kafka and deploy them using containers and pipelines.",
                Arrays.asList("java", "spring boot", "microservices", "docker", "kafka", "postgresql", "ci/cd"), 3));
        jobs.add(new Job(7, "Concurrency Engineer", "TradeGrid", "Mumbai",
                "Optimise low-latency trading components using threads, concurrent collections and profiling.",
                Arrays.asList("java", "multithreading", "collections", "data structures", "algorithms", "linux"), 3));
        jobs.add(new Job(8, "Frontend Developer", "Pixelcraft", "Remote",
                "Turn Figma designs into accessible, fast React interfaces.",
                Arrays.asList("javascript", "typescript", "react", "html", "css", "figma"), 1));
        jobs.add(new Job(9, "DevOps Engineer", "Cloudnest", "Hyderabad",
                "Automate builds and run Kubernetes clusters for product teams.",
                Arrays.asList("linux", "docker", "kubernetes", "aws", "ci/cd", "git"), 2));
        jobs.add(new Job(10, "Software Engineer Intern", "Bytewise", "Chandigarh",
                "Learn by building internal tools in Java with mentors. Strong fundamentals matter most.",
                Arrays.asList("java", "data structures", "algorithms", "oop", "git", "sql"), 0));
        jobs.add(new Job(11, "Database Developer", "Ledgerline", "Noida",
                "Design schemas, tune queries and build Java data access layers.",
                Arrays.asList("sql", "mysql", "postgresql", "jdbc", "java", "linux"), 2));
        jobs.add(new Job(12, "Android Developer", "Roam", "Remote",
                "Build and maintain a travel app for Android with REST backends and automated tests.",
                Arrays.asList("java", "oop", "rest api", "junit", "git", "agile"), 1));
        return jobs;
    }

    public static List<String> sampleResumes() {
        List<String> texts = new ArrayList<>();
        texts.add("Aarav Singh - B.Tech CSE student\naarav.singh@example.com\n"
                + "Skills: Java, OOP, Collections, multithreading, JDBC, MySQL, Git, HTML, CSS\n"
                + "Built a library management system using JDBC and MySQL. Solved 150 problems on data "
                + "structures and algorithms. Interested in REST APIs and Spring.");
        texts.add("Meera Kapoor, Data Scientist\nmeera.k@example.com\n"
                + "3 years of experience. Python, pandas, SQL, machine learning, TensorFlow, Docker, AWS, Git.\n"
                + "Deployed ML models on AWS and wrote ETL pipelines.");
        texts.add("Rohan Verma - Frontend Engineer\nrohan.verma@example.com\n"
                + "2 years of experience with JavaScript, TypeScript, ReactJS, HTML, CSS and Figma. "
                + "Also built small Node services with MongoDB.");
        texts.add("Simran Kaur - Backend Engineer\nsimran.kaur@example.com\n"
                + "5 years of experience. Java, Spring, microservices, Kafka, PostgreSQL, Docker, Kubernetes, "
                + "Jenkins, JUnit, Maven, multithreading and concurrency.");
        texts.add("Too short");     // invalid on purpose: triggers InvalidResumeException
        return texts;
    }
}
