@echo off
rem run.bat          interactive menu
rem run.bat --demo   automatic tour of every feature
java -cp "out;lib/*" com.resumematcher.ui.Main %*
