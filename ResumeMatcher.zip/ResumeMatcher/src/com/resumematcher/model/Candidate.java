package com.resumematcher.model;

/** A job seeker. Inherits from Person and overrides getRole() (polymorphism). */
public class Candidate extends Person {
    private final int yearsOfExperience;

    public Candidate(String name, String email, int yearsOfExperience) {
        super(name, email);
        this.yearsOfExperience = yearsOfExperience;
    }

    public int getYearsOfExperience() {
        return yearsOfExperience;
    }

    public ExperienceLevel getLevel() {
        return ExperienceLevel.fromYears(yearsOfExperience);
    }

    @Override
    public String getRole() {
        return "Candidate";
    }
}
