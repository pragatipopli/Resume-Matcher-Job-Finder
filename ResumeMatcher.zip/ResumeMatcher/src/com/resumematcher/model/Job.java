package com.resumematcher.model;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

public class Job {
    private final int id;
    private final String title;
    private final String company;
    private final String location;
    private final String description;
    private final Set<String> requiredSkills = new LinkedHashSet<>();
    private final int minYears;

    public Job(int id, String title, String company, String location, String description,
               Collection<String> skills, int minYears) {
        this.id = id;
        this.title = title;
        this.company = company;
        this.location = location;
        this.description = description;
        this.minYears = minYears;
        for (String s : skills) {
            requiredSkills.add(s.toLowerCase());
        }
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getCompany() { return company; }
    public String getLocation() { return location; }
    public String getDescription() { return description; }
    public int getMinYears() { return minYears; }

    public Set<String> getRequiredSkills() {
        return Collections.unmodifiableSet(requiredSkills);
    }

    /** Text used by the TF-IDF matcher. */
    public String getSearchText() {
        return title + " " + description + " " + String.join(" ", requiredSkills);
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Job && ((Job) o).id == id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }

    @Override
    public String toString() {
        return "[" + id + "] " + title + " @ " + company + " (" + location + ")";
    }
}
