package com.resumematcher.matcher;

import com.resumematcher.model.Job;
import com.resumematcher.model.Resume;
import com.resumematcher.util.TextUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

/**
 * Cosine similarity between resume text and job text, using TF-IDF vectors built by hand.
 * TF = how often a word appears; IDF = how rare the word is across all jobs.
 */
public class TfIdfMatcher extends AbstractMatcher {
    private final Map<String, Integer> docFreq = new HashMap<>();
    private final Map<Integer, Map<String, Double>> jobVectors = new HashMap<>();
    private final int docCount;

    public TfIdfMatcher(List<Job> jobs) {
        this.docCount = jobs.size();
        List<List<String>> docs = new ArrayList<>();
        for (Job job : jobs) {
            List<String> tokens = TextUtils.tokenize(job.getSearchText());
            docs.add(tokens);
            for (String word : new HashSet<>(tokens)) {      // count each word once per document
                docFreq.merge(word, 1, Integer::sum);
            }
        }
        for (int i = 0; i < jobs.size(); i++) {
            jobVectors.put(jobs.get(i).getId(), vectorize(docs.get(i)));
        }
    }

    @Override
    public double score(Resume resume, Job job) {
        Map<String, Double> resumeVector = vectorize(TextUtils.tokenize(resume.getRawText()));
        double cosine = cosine(resumeVector, vectorOf(job));
        return Math.min(1.0, cosine * 3);       // raw cosine on long text is small, so stretch it
    }

    @Override
    public String name() {
        return "TF-IDF";
    }

    private double idf(String word) {
        return Math.log((docCount + 1.0) / (docFreq.getOrDefault(word, 0) + 1.0)) + 1.0;
    }

    private Map<String, Double> vectorize(List<String> tokens) {
        Map<String, Double> vector = new HashMap<>();
        for (String t : tokens) {
            vector.merge(t, 1.0, Double::sum);               // term frequency
        }
        for (Map.Entry<String, Double> e : vector.entrySet()) {
            e.setValue(e.getValue() * idf(e.getKey()));      // times inverse document frequency
        }
        return vector;
    }

    private Map<String, Double> vectorOf(Job job) {
        Map<String, Double> cached = jobVectors.get(job.getId());
        return cached != null ? cached : vectorize(TextUtils.tokenize(job.getSearchText()));
    }

    private static double cosine(Map<String, Double> a, Map<String, Double> b) {
        double dot = 0, normA = 0, normB = 0;
        for (Map.Entry<String, Double> e : a.entrySet()) {
            normA += e.getValue() * e.getValue();
            Double other = b.get(e.getKey());
            if (other != null) {
                dot += e.getValue() * other;
            }
        }
        for (double v : b.values()) {
            normB += v * v;
        }
        return (normA == 0 || normB == 0) ? 0.0 : dot / (Math.sqrt(normA) * Math.sqrt(normB));
    }
}
