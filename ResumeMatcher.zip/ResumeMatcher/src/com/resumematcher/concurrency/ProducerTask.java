package com.resumematcher.concurrency;

import java.util.List;

/** Puts raw resume texts into the queue, then one poison pill per consumer. */
public class ProducerTask implements Runnable {
    private final ResumeQueue queue;
    private final List<String> texts;
    private final int consumerCount;

    public ProducerTask(ResumeQueue queue, List<String> texts, int consumerCount) {
        this.queue = queue;
        this.texts = texts;
        this.consumerCount = consumerCount;
    }

    @Override
    public void run() {
        try {
            for (String text : texts) {
                queue.put(text);
                System.out.println("  [" + Thread.currentThread().getName() + "] queued a resume (queue size "
                        + queue.size() + ")");
                Thread.sleep(40);                 // TIMED_WAITING: simulates slow input
            }
            for (int i = 0; i < consumerCount; i++) {
                queue.put(ResumeQueue.POISON_PILL);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();   // restore the interrupt flag
        }
    }
}
