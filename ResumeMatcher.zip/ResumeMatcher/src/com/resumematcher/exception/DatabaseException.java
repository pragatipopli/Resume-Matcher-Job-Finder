package com.resumematcher.exception;

/** Unchecked exception wrapping SQLException so callers are not forced to catch it. */
public class DatabaseException extends RuntimeException {
    public DatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}
