package com.resumematcher.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** String-handling helpers: StringBuilder avoids creating many String objects in loops. */
public final class TextUtils {
    // HashSet: contains() is fast, order does not matter
    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
            "a", "an", "the", "and", "or", "of", "to", "in", "for", "with", "on", "at", "by", "is", "are",
            "was", "were", "be", "as", "it", "this", "that", "from", "i", "my", "we", "you", "our", "your",
            "have", "has", "had", "will", "can", "into", "using", "use", "used", "work", "worked",
            "working", "experience", "project", "projects"));

    private TextUtils() { }

    /** Lower-cases text and keeps only letters, digits, + and #; keeps . and / only inside words (node.js, ci/cd). */
    public static String normalize(String text) {
        if (text == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(text.length());
        int n = text.length();
        for (int i = 0; i < n; i++) {
            char c = text.charAt(i);
            boolean inside = i > 0 && i < n - 1
                    && Character.isLetterOrDigit(text.charAt(i - 1))
                    && Character.isLetterOrDigit(text.charAt(i + 1));
            if (Character.isLetterOrDigit(c) || c == '+' || c == '#') {
                sb.append(Character.toLowerCase(c));
            } else if ((c == '.' || c == '/') && inside) {
                sb.append(c);
            } else {
                sb.append(' ');
            }
        }
        return sb.toString().replaceAll("\\s+", " ").trim();
    }

    /** Splits normalized text into tokens, dropping stop words and one-letter tokens. */
    public static List<String> tokenize(String text) {
        List<String> tokens = new ArrayList<>();
        String normalized = normalize(text);
        if (normalized.isEmpty()) {
            return tokens;
        }
        for (String word : normalized.split(" ")) {
            if (word.length() > 1 && !STOP_WORDS.contains(word)) {
                tokens.add(word);
            }
        }
        return tokens;
    }

    public static String repeat(String s, int times) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < times; i++) {
            sb.append(s);
        }
        return sb.toString();
    }
}
