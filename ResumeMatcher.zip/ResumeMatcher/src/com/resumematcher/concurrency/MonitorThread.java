package com.resumematcher.concurrency;

/** Daemon thread that reports progress; it never keeps the JVM alive on its own. */
public class MonitorThread extends Thread {
    private final SharedResultStore store;
    private final int expected;

    public MonitorThread(SharedResultStore store, int expected) {
        super("monitor");
        this.store = store;
        this.expected = expected;
        setDaemon(true);
        setPriority(Thread.MIN_PRIORITY);
    }

    @Override
    public void run() {
        try {
            while (!isInterrupted()) {
                System.out.println("  [monitor] " + store.getProcessed() + "/" + expected + " resumes processed");
                Thread.sleep(60);
            }
        } catch (InterruptedException e) {
            // normal way to stop this thread
        }
    }
}
