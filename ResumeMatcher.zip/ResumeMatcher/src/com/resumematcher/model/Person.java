package com.resumematcher.model;

/** Abstract base class (abstraction + inheritance). */
public abstract class Person {
    protected final String name;
    protected final String email;

    protected Person(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public abstract String getRole();

    @Override
    public String toString() {
        return getRole() + ": " + name + " <" + email + ">";
    }
}
